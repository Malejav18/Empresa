package controlador;


import Vista.UIVenta;
import dao.VentaDao;
import dto.Venta;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class controladorVenta implements ActionListener{

    private VentaDao modeloVenta;
    private UIVenta  vistaVenta;
    private DefaultTableModel modeloT;

    public controladorVenta(UIVenta vistaVenta) {
        this.vistaVenta = vistaVenta;
        this.modeloVenta =new VentaDao();
        
        this.vistaVenta = vistaVenta;
        this.vistaVenta.ConsultarVenta.addActionListener(this);
        this.vistaVenta.ActualizarVenta.addActionListener(this);
        this.vistaVenta.RegistrarVenta.addActionListener(this);
        this.vistaVenta.TodoVenta.addActionListener(this);

        this.modeloT = (DefaultTableModel) vistaVenta.TablaVenta.getModel();
        this.vistaVenta.setVisible(true);
    }
    
    public void llenarTabla(){
        List<Venta> listaVentas = modeloVenta.leerTodo();
            
            int filas = modeloT.getRowCount();
            
            for (int i = 0; i < filas; i++) {
                modeloT.removeRow(0);
            }
            
            for (Venta venta : listaVentas) {

               Object[] fila= {venta.getNumeroVenta(), venta.getNombreProdcucto(), venta.getCodigoProducto(), venta.getCantidadComprada(), venta.getNombreCliente(), venta.getIdCliente(), venta.getFechaCotizacion(), venta.getFechaEntrega()};
               modeloT.addRow(fila);
            }
    }
        
    @Override
    public void actionPerformed(ActionEvent e) {
       if(e.getSource() == vistaVenta.RegistrarVenta){
            Venta venta =new Venta();
            List<Venta> listaVentas = modeloVenta.leerTodo();
            
            int numeroV = Integer.valueOf(vistaVenta.numeroVenta.getText());
            String nombreP = vistaVenta.nombreProducto.getText();
            int codigoP = Integer.valueOf(vistaVenta.codigoProducto.getText());
            int cantidadC = Integer.valueOf(vistaVenta.cantidadComprada.getText());
            String nombreC = vistaVenta.cliente.getText();
            int idCliente = Integer.valueOf(vistaVenta.idCliene.getText());
            String fechaC = (vistaVenta.fechaCotizacion.getText());
            String fechaE = (vistaVenta.fechaEntrega.getText());
            
            venta.setNumeroVenta(numeroV);
            venta.setNombreProdcucto(nombreP);
            venta.setCodigoProducto(codigoP);
            venta.setCantidadComprada(cantidadC);
            venta.setNombreCliente(nombreC);
            venta.setIdCliente(idCliente);
            venta.setFechaCotizacion(fechaC);
            venta.setFechaEntrega(fechaE);
            
            modeloVenta.registrar(venta);
                JOptionPane.showMessageDialog(null,"Se ha registrado una venta");
           
           Object[] fila= {venta.getNumeroVenta(), venta.getNombreProdcucto(), venta.getCodigoProducto(), venta.getCantidadComprada(), venta.getNombreCliente(), venta.getIdCliente(), venta.getFechaCotizacion(), venta.getFechaEntrega()};
               modeloT.addRow(fila); 
        }
        /**
         * 
         */
        if(e.getSource() == this.vistaVenta.ConsultarVenta){
            int numero = Integer.valueOf(this.vistaVenta.numeroVenta.getText());
            Venta venta = this.modeloVenta.consultar(numero);

            if(venta==null){
                JOptionPane.showMessageDialog(null, "Venta no egistrada");
            }else{
                this.vistaVenta.numeroVenta.setText(String.valueOf(venta.getNumeroVenta()));
                this.vistaVenta.nombreProducto.setText(venta.getNombreProdcucto());
                this.vistaVenta.codigoProducto.setText(String.valueOf(venta.getCodigoProducto()));
                this.vistaVenta.cantidadComprada.setText(String.valueOf(venta.getCantidadComprada()));
                this.vistaVenta.cliente.setText(venta.getNombreCliente());
                this.vistaVenta.idCliene.setText(String.valueOf(venta.getIdCliente()));
                this.vistaVenta.fechaCotizacion.setText(venta.getFechaCotizacion());
                this.vistaVenta.fechaEntrega.setText(venta.getFechaEntrega());

            }
        }
        
        if(e.getSource() == vistaVenta.TodoVenta){
            List<Venta> listaVentas = modeloVenta.leerTodo();
            
            
            int filas = modeloT.getRowCount();
                for (int i = 0; i < filas; i++) {
                    modeloT.removeRow(0);
                }
            
                for (Venta venta : listaVentas) {
                    Object[] fila= {venta.getNumeroVenta(), venta.getNombreProdcucto(), venta.getCodigoProducto(), venta.getCantidadComprada(), venta.getNombreCliente(), venta.getIdCliente(), venta.getFechaCotizacion(), venta.getFechaEntrega()};
                    modeloT.addRow(fila);
                }
        }   
        /**
         * 
         */
      //  if(e.getSource() == vistaProducto.actualizar){
     //       modeloProducto.actualizar(producto);
      //      if(modeloProducto.actualizar(producto) == null)
      //          JOptionPane.showMessageDialog(null,"Se ha actualizado un producto");
        
     //   
    }
}

