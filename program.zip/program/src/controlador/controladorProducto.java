package controlador;


import Vista.UIProducto;
import dao.ProductoDao;
import dto.Producto;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class controladorProducto implements ActionListener{

    private ProductoDao modeloProducto;
    private UIProducto  vistaProducto;
    private DefaultTableModel modeloT;
    
    public controladorProducto(UIProducto vistaProducto) {
        this.vistaProducto = vistaProducto;
        this.modeloProducto =new ProductoDao();
        
        this.vistaProducto = vistaProducto;
        this.vistaProducto.ActualizarProducto.addActionListener(this);
        this.vistaProducto.RegistrarProducto.addActionListener(this);
        this.vistaProducto.TodoProducto.addActionListener(this);
        
        this.modeloT = (DefaultTableModel) vistaProducto.TablaProductos.getModel();
        this.vistaProducto.setVisible(true);
        
    }
    
    public void llenarTabla(){
        List<Producto> listaProductos = modeloProducto.leerTodo();
            
            int filas = modeloT.getRowCount();
            
            for (int i = 0; i < filas; i++) {
                modeloT.removeRow(0);
            }
            
            for (Producto producto : listaProductos) {

               Object[] fila= {producto.getNombreProducto(), producto.getCodigoProducto(), producto.getCantidadProducto(), producto.getPrecioU(), producto.getDetalles()};
               modeloT.addRow(fila);
            }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == vistaProducto.RegistrarProducto){
            Producto producto =new Producto();
            List<Producto> listaProductos = modeloProducto.leerTodo();
            String nombre = vistaProducto.nombreProducto.getText();
            int codigo = Integer.valueOf(vistaProducto.codigoProducto.getText());
            int cantidad = Integer.valueOf(vistaProducto.cantidadProducto.getText());
            int precio = Integer.valueOf(vistaProducto.precio.getText());
            String detalles = vistaProducto.detalles.getText();
            
            producto.setNombreProducto(nombre);
            producto.setCodigoProducto(codigo);
            producto.setCantidadProducto(cantidad);
            producto.setPrecioU(precio);
            producto.setDetalles(detalles);
            
            modeloProducto.registrar(producto);

            JOptionPane.showMessageDialog(null,"Se ha registrado un producto");

           Object[] fila= {producto.getNombreProducto(), producto.getCodigoProducto(), producto.getCantidadProducto(), producto.getPrecioU(), producto.getDetalles()};
               modeloT.addRow(fila); 
        }
        /**
         * 
         */
        if(e.getSource() == this.vistaProducto.ConsultarProducto){
            int codigo = Integer.valueOf(this.vistaProducto.codigoProducto.getText());
            Producto producto = this.modeloProducto.consultar(codigo);

            if(producto==null){
                JOptionPane.showMessageDialog(null, "Producto no egistrado");
            }else{
                this.vistaProducto.nombreProducto.setText(producto.getNombreProducto());
                this.vistaProducto.codigoProducto.setText(String.valueOf(producto.getCodigoProducto()));
                this.vistaProducto.cantidadProducto.setText(String.valueOf(producto.getCantidadProducto()));
                this.vistaProducto.precio.setText(String.valueOf(producto.getPrecioU()));
                this.vistaProducto.detalles.setText(producto.getDetalles());

            }
        }
        
        if(e.getSource() == vistaProducto.TodoProducto){
            List<Producto> listaProductos = modeloProducto.leerTodo();
            
            int filas = modeloT.getRowCount();
                for (int i = 0; i < filas; i++) {
                    modeloT.removeRow(0);
                }
            
                for (Producto producto : listaProductos) {
                    Object[] fila= {producto.getNombreProducto(), producto.getCodigoProducto(), producto.getCantidadProducto(), producto.getPrecioU(), producto.getDetalles()};
                    modeloT.addRow(fila);
                }
        }   
        /**
         * 
         */
      //  if(e.getSource() == vistaProducto.actualizar){
     //       modeloProducto.actualizar(producto);
      //      if(modeloProducto.actualizar(producto) == null)
      //          JOptionPane.showMessageDialog(null,"Se ha actualizado un producto");
        
     //   
    }
}
