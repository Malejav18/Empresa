package controlador;


import Vista.UICliente;
import Vista.UIPrincipal;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class controladorPrincipal  implements ActionListener {
    private final UIPrincipal vistaP;

    public controladorPrincipal(UIPrincipal vistaP) {
        this.vistaP = vistaP;
        
        this.vistaP.jMICliente.addActionListener(this);
        
        this.vistaP.setVisible(true);
    
    
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JOptionPane.showMessageDialog(null,"Hola");
        if(e.getSource() == vistaP.jMICliente){
        
            controladorCliente controlCliente =new controladorCliente(new UICliente());
        
        
        }
    
    
    }
    
    

    
    
}

