/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author Salas
 */
public class Venta {
    private int numeroVenta;
    private String nombreProdcucto;
    private int codigoProducto;
    private int cantidadComprada;
    private String nombreCliente;
    private int idCliente;
    private int fechaCotizacion;
    private int fechaEntrega;

    public int getNumeroVenta() {
        return numeroVenta;
    }

    public void setNumeroVenta(int numeroVenta) {
        this.numeroVenta = numeroVenta;
    }

    public String getNombreProdcucto() {
        return nombreProdcucto;
    }

    public void setNombreProdcucto(String nombreProdcucto) {
        this.nombreProdcucto = nombreProdcucto;
    }

    public int getCodigoProducto() {
        return codigoProducto;
    }

    public void setCodigoProducto(int codigoProducto) {
        this.codigoProducto = codigoProducto;
    }

    public int getCantidadComprada() {
        return cantidadComprada;
    }

    public void setCantidadComprada(int cantidadComprada) {
        this.cantidadComprada = cantidadComprada;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public int getFechaCotizacion() {
        return fechaCotizacion;
    }

    public void setFechaCotizacion(int fechaCotizacion) {
        this.fechaCotizacion = fechaCotizacion;
    }

    public int getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(int fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

}