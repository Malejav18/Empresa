/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import Vista.UICliente;
import Vista.UIPrincipal;
import controlador.controladorCliente;
import controlador.controladorPrincipal;

/**
 *
 * @author macbook
 */
public class main {
    
     public static void main(String[] args) {
         
         new controladorPrincipal(new UIPrincipal());
         //new controladorCliente(new UICliente() );
         
         
     }
    
}
