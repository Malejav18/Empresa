
import Vista.UICliente;
import Vista.UIPrincipal;
import Vista.UIProducto;
import Vista.UIVenta;
import controlador.controladorCliente;

public class controladorPrincipal  {

    private UIPrincipal UIPrincipal;
    private controladorVenta controladorVenta;
    private controladorProducto controladorProducto;
    private controladorCliente controladorCliente;

    public controladorPrincipal(UIPrincipal uiPrincipal, controladorVenta controladorVenta, controladorProducto controladorProducto, controladorCliente controladorCliente) {
        this.UIPrincipal = uiPrincipal;
        this.controladorVenta = controladorVenta;
        this.controladorProducto = controladorProducto;
        this.controladorCliente = controladorCliente;

        uiPrincipal.setController(this);
    }

    public void mostrarVistaPrincipal() {
        UIPrincipal.mostrar();
    }

    public void mostrarVistaVenta() {
        UIVenta uiVenta = new UIVenta();
        uiVenta.setController(controladorVenta);
       UIPrincipal.mostrarVista(uiVenta);
    }

    public void mostrarVistaProducto() {
        UIProducto uiProducto = new UIProducto();
        uiProducto.setController(controladorProducto);
        UIPrincipal.mostrarVista(uiProducto);
    }

    public void mostrarVistaCliente() {
        UICliente uiCliente = new UICliente();
        uiCliente.setControlador(controladorCliente);
        UIPrincipal.mostrarVista(uiCliente);
    }
}
