package controlador;


import dao.ClienteDao;
import dto.Cliente;

public class controladorCliente {

    private final ClienteDao clienteDao;

    public controladorCliente(ClienteDao clienteDao) {
        this.clienteDao = clienteDao;
    }

    public void guardarCliente(Cliente cliente) {
        clienteDao.guardarCliente(cliente);
    }

    public Cliente consultarCliente(int id) {
        return clienteDao.consultarCliente(id);
    }

    public void actualizarCliente(Cliente cliente) {
        clienteDao.actualizarCliente(cliente);
    }

    public void eliminarCliente(int id) {
        clienteDao.eliminarCliente(id);
    }
}



