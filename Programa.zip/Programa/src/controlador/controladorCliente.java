package controlador;


import Vista.UICliente;
import dao.ClienteDao;
import dto.Cliente;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class controladorCliente implements ActionListener{

    private ClienteDao modeloCliente;
    private UICliente  vistaCliente;
    private DefaultTableModel modeloT;

    public controladorCliente(UICliente vistaCliente) {
        this.vistaCliente = vistaCliente;
        this.modeloCliente =new ClienteDao();
        
        this.vistaCliente.ConsultarCliente.addActionListener(this);
        this.vistaCliente.setVisible(true);
        
        this.vistaCliente.ActualizarCliente.addActionListener(this);
        this.vistaCliente.setVisible(true);
        
        this.vistaCliente.RegistrarCliente.addActionListener(this);
        this.vistaCliente.setVisible(true);
        
        this.vistaCliente.TodoCliente.addActionListener(this);
        this.vistaCliente.setVisible(true);
        
        this.modeloT = (DefaultTableModel) vistaCliente.ConsultarCliente.getModel();
    }
    
    public void llenarTabla(){
        List<Cliente> listaClientes = modeloCliente.leerTodo();
            
            int filas = modeloT.getRowCount();
            
            for (int i = 0; i < filas; i++) {
                modeloT.removeRow(0);
            }
            
            for (Cliente cliente : listaClientes) {
                
                
               Object[] fila= {cliente.getNombreCliente(), cliente.getIdCliente(), cliente.getCorreo(), cliente.getDireccion(), cliente.getNumeroCliente()};
               modeloT.addRow(fila);
            }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == this.vistaCliente.ConsultarCliente){
            int id = Integer.valueOf(this.vistaCliente.idCliente.getText());
            Cliente cliente = this.modeloCliente.consultar(id);

            if(cliente==cliente)
                 JOptionPane.showMessageDialog(null, "|Cliente no egistrado");
            else
             //   this.vistaCliente.nombreCliente.setText(cliente.getNombreCliente());
               // this.vistaCliente.idCliente.setText(String.valueOf(cliente.getIdCliente()));
               // this.vistaCliente.correo.setText(cliente.getCorreo());
              //  this.vistaCliente.direccion.setText(cliente.getDireccion());
               // this.vistaCliente.numeroCliente.setText(String.valueOf(cliente.getNumeroCliente()));
        }
   
        /**
         * 
         */
        if(e.getSource() == vistaCliente.ActualizarCliente){
     //       modeloCliente.actualizar(cliente);
      //      if(modeloCliente.actualizar(cliente) == null)
                JOptionPane.showMessageDialog(null,"Se ha actualizado un cliente");
        
        }
        
        /**
         * 
         */
        if(e.getSource() == vistaCliente.RegistrarCliente){
            Cliente cliente =new Cliente();
            List<Cliente> listaClientes = modeloCliente.leerTodo();
            String nombre = vistaCliente.nombreCliente.getText();
            int id = Integer.valueOf(vistaCliente.idCliente.getText());
            String correo = vistaCliente.correo.getText();
            String direccion = vistaCliente.direccion.getText();
            int numero = Integer.valueOf(vistaCliente.numeroCliente.getText());
            
            cliente.setIdCliente(id);
            cliente.setNombreCliente(nombre);
            cliente.setCorreo(correo);
            cliente.setDireccion(direccion);
            cliente.setNumeroCliente(numero);
            
            modeloCliente.registrar(cliente);
            
         //   if(modeloCliente.registrar(cliente) == null)
                JOptionPane.showMessageDialog(null,"Se ha registrado un cliente");
           // else
                JOptionPane.showMessageDialog(null, "Usuario No Guardado");
            
            

           modeloCliente.registrar(cliente);
           
           Object[] fila= {cliente.getNombreCliente(),cliente.getIdCliente(), cliente.getCorreo(), cliente.getDireccion(), cliente.getNumeroCliente()};
               modeloT.addRow(fila);
            
        }
         /**
          * 
          */
        if(e.getSource() == vistaCliente.TodoCliente){
            JOptionPane.showMessageDialog(null,"Los clientes son:");
        
            if(e.getSource() == this.vistaCliente.TodoCliente){
                List<Cliente> listaClientes = modeloCliente.leerTodo();
            
                int filas = modeloT.getRowCount();
            
                for (int i = 0; i < filas; i++) {
                    modeloT.removeRow(0);
                }
            
                for (Cliente cliente : listaClientes) {
                    Object[] fila= {cliente.getNombreCliente(),cliente.getIdCliente(), cliente.getCorreo(), cliente.getDireccion(), cliente.getNumeroCliente()};
                    modeloT.addRow(fila);
                }
            }   
        }
        
        if(e.getSource() == vistaCliente.BorrarCliente){
            Cliente cliente =new Cliente();
            String nombre = vistaCliente.nombreCliente.getText();
            int id = Integer.valueOf(vistaCliente.idCliente.getText());
            String correo = vistaCliente.correo.getText();
            String direccion = vistaCliente.direccion.getText();
            int numero = Integer.valueOf(vistaCliente.numeroCliente.getText());
            
            cliente.setIdCliente(id);
            cliente.setNombreCliente(nombre);
            cliente.setCorreo(correo);
            cliente.setDireccion(direccion);
            cliente.setNumeroCliente(numero);
            
            modeloCliente.borrar(cliente);
           
           Object[] fila= {cliente.getNombreCliente(),cliente.getIdCliente(), cliente.getCorreo(), cliente.getDireccion(), cliente.getNumeroCliente()};
               modeloT.addRow(fila);
        
    }
}}
