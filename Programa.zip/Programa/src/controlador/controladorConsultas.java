package controlador;


import dao.VentaDao;
import dto.Venta;
import java.util.List;

public class controladorConsultas {

    private final VentaDao ventaDao;

    public controladorConsultas(VentaDao ventaDao) {
        this.ventaDao = ventaDao;
    }

    public List<Venta> consultarTodasLasVentas() {
        return ventaDao.consultarTodasLasVentas();
    }
}
