package controlador;


import Vista.UIVenta;
import dao.VentaDao;
import dto.Venta;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class controladorVenta implements ActionListener{

    private VentaDao modeloVenta;
    private UIVenta  vistaVenta;

    public controladorVenta(UIVenta vistaVenta) {
        this.vistaVenta = vistaVenta;
        this.modeloVenta =new VentaDao();
        
        this.vistaVenta.ConsultarVenta.addActionListener(this);
        this.vistaVenta.setVisible(true);
        
        this.vistaVenta.ActualizarVenta.addActionListener(this);
        this.vistaVenta.setVisible(true);
        
        this.vistaVenta.RegistrarVenta.addActionListener(this);
        this.vistaVenta.setVisible(true);
        
        this.vistaVenta.TodoVenta.addActionListener(this);
        this.vistaVenta.setVisible(true);
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == vistaVenta.ConsultarVenta){
            JOptionPane.showMessageDialog(null,"Consultando venta");
        
        }
        if(e.getSource() == vistaVenta.ActualizarVenta){
            JOptionPane.showMessageDialog(null,"Se ha actualizado una venta");
        
        }
        if(e.getSource() == vistaVenta.RegistrarVenta){
            JOptionPane.showMessageDialog(null,"Se ha registrado una venta");
        
        }
        if(e.getSource() == vistaVenta.TodoVenta){
            JOptionPane.showMessageDialog(null,"Las ventas son:");
        
        }
       
    }
}

