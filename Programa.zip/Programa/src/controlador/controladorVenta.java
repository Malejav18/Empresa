
import dao.VentaDao;
import dto.Venta;

public class controladorVenta {

    private final VentaDao ventaDao;

    public controladorVenta(VentaDao ventaDao) {
        this.ventaDao = ventaDao;
    }

    public void guardarVenta(Venta venta) {
        ventaDao.guardarVenta(venta);
    }

    public Venta consultarVenta(int numeroVenta) {
        return ventaDao.consultarVenta(numeroVenta);
    }

    public void actualizarVenta(Venta venta) {
        ventaDao.actualizarVenta(venta);
    }

    public void eliminarVenta(int numeroVenta) {
        ventaDao.eliminarVenta(numeroVenta);
    }
}

