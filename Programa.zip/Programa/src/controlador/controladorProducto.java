package controlador;


import Vista.UIProducto;
import dao.ProductoDao;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class controladorProducto implements ActionListener{

    private ProductoDao modeloProducto;
    private UIProducto  vistaProducto;

    public controladorProducto(UIProducto vistaProducto) {
        this.vistaProducto = vistaProducto;
        this.modeloProducto =new ProductoDao();
        
        this.vistaProducto.ConsultarProducto.addActionListener(this);
        this.vistaProducto.setVisible(true);
        
        this.vistaProducto.ActualizarProducto.addActionListener(this);
        this.vistaProducto.setVisible(true);
        
        this.vistaProducto.RegistrarProducto.addActionListener(this);
        this.vistaProducto.setVisible(true);
        
        this.vistaProducto.TodoProducto.addActionListener(this);
        this.vistaProducto.setVisible(true);
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == vistaProducto.ConsultarProducto){
            JOptionPane.showMessageDialog(null,"Consultando producto");
        
        }
        if(e.getSource() == vistaProducto.ActualizarProducto){
            JOptionPane.showMessageDialog(null,"Se ha actualizado un producto");
        
        }
        if(e.getSource() == vistaProducto.RegistrarProducto){
            JOptionPane.showMessageDialog(null,"Se ha registrado un producto");
        
        }
        if(e.getSource() == vistaProducto.TodoProducto){
            JOptionPane.showMessageDialog(null,"Los productos son:");
        
        }
       
    }
}
