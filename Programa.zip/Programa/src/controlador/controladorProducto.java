
import dao.ProductoDao;
import dto.Producto;

public class controladorProducto {

    private final ProductoDao productoDao;

    public controladorProducto(ProductoDao productoDao) {
        this.productoDao = productoDao;
    }

    public void guardarProducto(Producto producto) {
        productoDao.guardarProducto(producto);
    }

    public Producto consultarProducto(int numeroProducto) {
        return productoDao.consultarProducto(numeroProducto);
    }

    public void actualizarProducto(Producto producto) {
        productoDao.actualizarProducto(producto);
    }

    public void eliminarProducto(int numeroProducto) {
        productoDao.eliminarProducto(numeroProducto);
    }
}
