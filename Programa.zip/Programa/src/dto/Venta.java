/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author Salas
 */
public class Venta {
    private int numeroVenta;
    private Producto nombreProdcucto;
    private Producto codigoProducto;
    private int cantidadComprada;
    private Cliente nombreCliente;
    private Cliente idCliente;
    private int fechaCotizacion;
    private int fechaEntrega;

    public int getNumeroVenta() {
        return numeroVenta;
    }

    public void setNumeroVenta(int numeroVenta) {
        this.numeroVenta = numeroVenta;
    }

    public Producto getNombreProdcucto() {
        return nombreProdcucto;
    }

    public void setNombreProdcucto(Producto nombreProdcucto) {
        this.nombreProdcucto = nombreProdcucto;
    }

    public Producto getCodigoProducto() {
        return codigoProducto;
    }

    public void setCodigoProducto(Producto codigoProducto) {
        this.codigoProducto = codigoProducto;
    }

    public int getCantidadComprada() {
        return cantidadComprada;
    }

    public void setCantidadComprada(int cantidadComprada) {
        this.cantidadComprada = cantidadComprada;
    }

    public Cliente getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(Cliente nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public Cliente getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(Cliente idCliente) {
        this.idCliente = idCliente;
    }

    public int getFechaCotizacion() {
        return fechaCotizacion;
    }

    public void setFechaCotizacion(int fechaCotizacion) {
        this.fechaCotizacion = fechaCotizacion;
    }

    public int getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(int fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }
    
}